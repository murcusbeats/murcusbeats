# MURCUS BEATS website

A mobile-friendly red-and-black static website for Murcus Beats.

## Preview
Open `index.html` in a browser.

## Add your music
1. Put an MP3 you created or have permission to distribute inside `assets/audio/`.
2. Open `index.html` in a text editor.
3. Find `const tracks = [` near the bottom.
4. Add a track entry, for example:

```js
{
  title: "My Afrobeats Single",
  type: "Original single",
  file: "assets/audio/my-song.mp3",
  download: true
}
```

5. Save the file and upload the updated website folder. Use `download: false` if you want streaming only.

The player and download links only work after the actual audio file is added and the track entry points to the correct filename. Do not upload music you do not own or have permission to distribute.

## Publish free with GitHub Pages
GitHub Pages can host a static website from a public GitHub repository on the free plan.
1. Create/sign in to GitHub.
2. Create a public repository named `murcusbeats`.
3. Upload `index.html` and the `assets` folder (keep the folder structure).
4. In repository Settings → Pages, choose deployment from the `main` branch and `/ (root)`, then save.
5. GitHub will show your free website address, usually `https://YOUR-USERNAME.github.io/murcusbeats/`.

Official guide: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## About murcusbeats.com
A custom `.com` domain must be registered separately and normally costs money. Once you own it, GitHub Pages supports connecting it through the repository's Pages settings and your domain provider's DNS settings:
https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site

This is a static website. It does not include a server-side upload dashboard or a hosted music database; to add public releases, update the track list and redeploy the site.
